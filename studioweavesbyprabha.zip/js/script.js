/* ================= HELPERS ================= */

const formatCategoryName = (name) =>
  name.charAt(0).toUpperCase() + name.slice(1);


/* ================= CATEGORY SWITCH ================= */

function showCategory(categoryId, el) {
  document.querySelectorAll(".category")
    .forEach(c => c.classList.remove("active"));

  document.querySelectorAll(".tab")
    .forEach(t => t.classList.remove("active"));

  const activeSection = document.getElementById(categoryId);
  if (activeSection) {
    activeSection.classList.add("active");
    activeSection.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  if (el) el.classList.add("active");
}


/* ================= PRODUCTS ================= */

function loadProducts() {
  const container = document.getElementById("productContainer");
  const tabsContainer = document.getElementById("categoryTabs");

  if (!container || !tabsContainer || !window.products) return;

  container.innerHTML = "";
  tabsContainer.innerHTML = "";

  Object.entries(products).forEach(([category, items], index) => {

    /* ===== TAB ===== */
    const tab = document.createElement("button");
    tab.className = "tab";
    tab.textContent = formatCategoryName(category);

    tab.addEventListener("click", () => showCategory(category, tab));

    if (index === 0) tab.classList.add("active");
    tabsContainer.appendChild(tab);


    /* ===== SECTION ===== */
    const section = document.createElement("section");
    section.className = "category";
    section.id = category;

    if (index === 0) section.classList.add("active");


    /* ===== HEADER ===== */
    const header = document.createElement("div");
    header.className = "section-header";

    const title = document.createElement("h2");
    title.textContent = formatCategoryName(category);

    header.appendChild(title);
    section.appendChild(header);


    /* ===== CONTENT ===== */
    if (!items || items.length === 0) {

      section.innerHTML += `<p class="coming-msg">✨ Coming Soon</p>`;

    } else {

      const grid = document.createElement("div");
      grid.className = "products"; // 🔥 using grid instead of horizontal scroll

      items.forEach(img => {

        const card = document.createElement("div");
        card.className = "product-card";

        const image = document.createElement("img");
        image.src = `images/${category}/${img}`;
        image.alt = category;
        image.loading = "lazy";

        /* OPTIONAL: QUICK VIEW */
        image.addEventListener("click", () => openModal?.(image.src));

        card.appendChild(image);
        grid.appendChild(card);
      });

      section.appendChild(grid);
    }

    container.appendChild(section);
  });

  activateScrollHighlight(); // sync tab with scroll
}


/* ================= SCROLL ACTIVE TAB ================= */

function activateScrollHighlight() {
  const sections = document.querySelectorAll(".category");
  const tabs = document.querySelectorAll(".tab");

  window.addEventListener("scroll", () => {
    let current = "";

    sections.forEach(section => {
      const top = section.offsetTop - 120;
      if (window.scrollY >= top) {
        current = section.id;
      }
    });

    tabs.forEach(tab => {
      tab.classList.remove("active");
      if (tab.textContent.toLowerCase() === current) {
        tab.classList.add("active");
      }
    });
  });
}


/* ================= BANNERS ================= */

function loadBanners() {
  const track = document.getElementById("carouselTrack");
  if (!track || !window.banners) return;

  track.innerHTML = "";

  banners.forEach(img => {
    const image = document.createElement("img");
    image.src = `images/banner/${img}`;
    image.alt = "banner";
    image.loading = "lazy";

    track.appendChild(image);
  });
}


/* ================= SERVICES ================= */

function loadServiceGallery() {
  const imageContainer = document.getElementById("serviceImages");
  const videoContainer = document.getElementById("serviceVideos");

  if (!window.servicesGallery) return;

  imageContainer && (imageContainer.innerHTML = "");
  videoContainer && (videoContainer.innerHTML = "");

  servicesGallery.forEach(item => {

    const card = document.createElement("div");
    card.className = "gallery-card";

    if (item.type === "image" && imageContainer) {
      const img = document.createElement("img");
      img.src = `images/services/${item.src}`;
      img.loading = "lazy";

      card.appendChild(img);
      imageContainer.appendChild(card);
    }

    if (item.type === "video" && videoContainer) {
      const video = document.createElement("video");
      video.src = `videos/${item.src}`;
      video.controls = true;
      video.muted = true;
      video.loop = true;

      card.appendChild(video);
      videoContainer.appendChild(card);
    }
  });
}


/* ================= INIT ================= */

document.addEventListener("DOMContentLoaded", () => {
  loadProducts();
  loadBanners();
  loadServiceGallery();
});